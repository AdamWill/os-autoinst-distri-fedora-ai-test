# OpenQA-TestData repository

This repository contains test files that our openQA tests use for Desktop testing. The openQA tests do not use this repository directly; they use a tarball of this repository that lives in the os-autoinst-distri-fedora repository. That tarball must be updated whenever this repository is changed.

## Structure

### Directories

Notice the repository directory structure. There are several directories, such as:

* configuration
* documents 
* music 
* pictures 
* reference
* video

Each of those directories contains the data related to its name, i.e. documents are placed in `documents`, video files in `video`, etc. 

#### The `reference` directory

This directory is for *reference* files that might include command outputs from a working system, that you can use to compare with the same output from a tested machine. **Do not place anything else in this directory.**

#### The `configuration` directory

This directory contains *configuration* files for various applications that we do not want to create during the tests.

## Content

**When adding content, make sure that you respect the structure.**

After changing this repository, you must run `update-data-tarball.sh` in the os-autoinst-distri-fedora repository and commit the changed tarball to that repository.

For space demanding content, such as multimedia files or pdfs, make sure they are **as much compressed as possible** to keep the overall amount of transferred data low.

## Using this repository in openQA tests

To use this repository in a test, use the `download_testdata` subroutine located in the `lib/utils.pm` file.

The following example shows how you can use it in a test script:

    use utils;

    sub {
        download_testdata;
    }
