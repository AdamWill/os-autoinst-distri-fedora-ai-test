# Konkurz

Napadlo mě tak nakonec roku,  
že bych se mohl věnovat rocku.   
Rád bych si zahrál k poslechu, tanci  
gotiku, třeba, či renesanci.  

Mrknul jsem kolem, kdo to tak hrává,  
která že grupa bude ta pravá.  
Nesmí to býti žabaři žádní,  
nejlepší zdá se ten bigbít hradní.

Šel jsem na konkurz, ztratil den celý,  
kapelník hlavu (jak) tuřanské zelí.  
Vytáh' jsem nástroj, prohrábl struny,   
a on mi dává pokynů tuny.

Kdo chce s námi zpívat, kdo chce s námi hrát  
ten se musí dívat na můj prstoklad  
invenci si nežádám, vše vím nejlíp sám  
a komu se to nezdá, tomu sbohem dám. 

Prý že tam hrají obtížné rytmy  
snad sedum osmin, za světla, v přítmí  
aiolský, dórský, lydický modus  
a kdo to nezná, ten pije sodu.

On prý je schopný hrát i na rohy  
někomu hrozně smrděly nohy  
prý kajtru držím jak prase kosti  
snad nejsem dobrý pro něho dosti. 

Kdo chce s nima zpívat, kdo chce s nima hrát  
musí jejich písně neomylně znát  
nadto ještě třeba sluch mít jako rys  
kdo chce do kapely Canti Clitoris.

Prý se k nim hráči po stovkách derou  
nakonec praví, tak že mě berou  
dívá se na mě jak vlk na krůtu  
a prý mám krátkou na nácvik lhůtu.

Poctivě cvičím, dá se říct denně  
bolestí kvičím jak malé štěně  
a když to umím, hodím si mašli,  
prý už si dávno jiného našli.

Bude s nima zpívat, bude s nima hrát    
dostane se krásně na jakýkoliv hrad.  
To se pozná páteř pevná jako tis  
příště už se vyhnu Canti Clitoris.


